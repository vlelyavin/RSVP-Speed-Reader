# RSVP Speed Reader Chrome Extension - Installation Guide

## Quick Start

### 1. Add Extension Icons (Optional for Testing)

The extension needs three icon files in the `icons/` directory:
- `icon16.png` (16x16 pixels)
- `icon48.png` (48x48 pixels)
- `icon128.png` (128x128 pixels)

**For testing, you can skip this step.** Chrome will use a default icon.

To create icons quickly:
1. Use any online icon generator (search "create favicon online")
2. Upload a simple image or create a red "R" on black background
3. Download in the three sizes and save them to `extension/icons/`

### 2. Load Extension in Chrome

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `extension/` directory from this project
5. The extension should now appear in your extensions list

### 3. Test the Extension

1. Visit any webpage with text (e.g., Wikipedia, news article)
2. Select some text with your mouse
3. Right-click on the selected text
4. Click **"Read with RSVP"** from the context menu
5. The RSVP overlay should appear and start reading

### 4. Keyboard Shortcuts

Once the overlay is active:
- **Space**: Pause/Resume
- **Escape**: Close overlay
- **Left/Right Arrows**: Navigate words manually
- **R**: Reset to beginning
- **Up/Down Arrows**: Adjust speed

### 5. Settings

The overlay includes inline settings in the left sidebar:
- **Speed slider**: Adjust reading speed (100-1000 WPM)
- **Font slider**: Adjust font size (40-120px)

## Troubleshooting

### Context menu not appearing
- Make sure the extension is enabled in `chrome://extensions/`
- Verify you selected text before right-clicking
- Try refreshing the page

### Overlay not appearing
1. Open browser console (F12) and check for errors
2. Verify the extension loaded properly in `chrome://extensions/`
3. Check that all files are present in the `extension/` directory

### Styles not loading
- The CSS file must be listed in `web_accessible_resources` in `manifest.json`
- Try reloading the extension in `chrome://extensions/`

### Content script errors
- Make sure you're using a modern Chrome version (v88+)
- ES6 modules must be supported

## File Structure

```
extension/
├── manifest.json              # Extension configuration
├── background.js              # Context menu handler
├── content-script.js          # Main overlay logic
├── rsvp-core.js              # Core RSVP functions
├── styles/
│   ├── overlay.css           # Overlay styles
│   └── reset.css             # Style isolation
└── icons/
    ├── icon16.png            # Small icon (optional for testing)
    ├── icon48.png            # Medium icon (optional for testing)
    └── icon128.png           # Large icon (optional for testing)
```

## Development

### Making Changes

1. Edit the files in the `extension/` directory
2. Go to `chrome://extensions/`
3. Click the refresh icon on the RSVP Speed Reader extension
4. Test your changes on a webpage

### Debugging

- **Background script**: Right-click extension → "Inspect service worker"
- **Content script**: Open page console (F12) while overlay is active
- **Manifest errors**: Check `chrome://extensions/` for error messages

## Next Steps

If you want to publish the extension:
1. Add proper icons (see `icons/README.md`)
2. Test on multiple websites
3. Create a privacy policy (required by Chrome Web Store)
4. Prepare promotional images (1280x800 screenshot)
5. Pay the one-time $5 developer fee
6. Submit to Chrome Web Store

## Known Limitations

- No settings persistence (resets on page reload)
- No history tracking
- Text selection only (no PDF support)
- Works on web pages only (not on Chrome system pages)

This is a minimal, focused extension designed to do one thing well: read selected text with RSVP.
