/* RSVP Speed Reader - Core Functions (Extension Version) */

// Calculate ORP (Optimal Recognition Point) index
export function calculateORP(word) {
  const length = word.length;
  if (length <= 3) return 0;
  if (length <= 5) return 1;
  if (length <= 9) return 2;
  return 3;
}

// Parse text into words
export function parseText(text) {
  // Split by whitespace and filter empty strings
  return text
    .trim()
    .split(/\s+/)
    .filter((word) => word.length > 0);
}

// Check if word ends with punctuation
export function hasPunctuation(word) {
  return /[.,!?;:]$/.test(word);
}

// Calculate delay for word
export function calculateDelay(word, settings) {
  const baseDelay = (60 / settings.speed) * 1000; // Convert WPM to milliseconds
  const punctuationDelay = hasPunctuation(word) ? settings.punctuationPause : 0;
  return baseDelay + punctuationDelay;
}

// Escape HTML to prevent XSS
export function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// Measure text width helper
let measureElement = null;
export function getTextWidth(text, fontSize, fontFamily) {
  if (!measureElement) {
    measureElement = document.createElement("span");
    measureElement.style.position = "absolute";
    measureElement.style.visibility = "hidden";
    measureElement.style.whiteSpace = "nowrap";
    document.body.appendChild(measureElement);
  }
  measureElement.style.fontSize = fontSize + "px";
  measureElement.style.fontFamily = fontFamily;
  measureElement.textContent = text;
  return measureElement.offsetWidth;
}
