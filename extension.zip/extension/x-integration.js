// X (Twitter) Integration for RSVP Speed Reader
// Injects "Speed read" option into post/article menus

(function() {
  'use strict';

  // Detect if we're on X/Twitter
  if (!window.location.hostname.match(/^(www\.)?(twitter|x)\.com$/)) {
    return;
  }

  // Track which menus we've already processed
  const processedMenus = new WeakSet();

  // Get current theme
  function isDarkTheme() {
    const bodyBg = window.getComputedStyle(document.body).backgroundColor;
    return bodyBg === 'rgb(0, 0, 0)' || bodyBg === 'rgba(0, 0, 0, 1)';
  }

  // Icon SVG for "Speed read" option (eye icon matching X's style)
  function getSpeedReadIcon() {
    const iconColor = isDarkTheme() ? 'rgb(239, 243, 244)' : 'rgb(15, 20, 25)';

    return `<svg viewBox="0 0 24 24" aria-hidden="true" style="width: 18.75px; height: 18.75px;">
      <g><path fill="${iconColor}" d="M12 4.5C7.305 4.5 3.2 7.29 1.05 11.4c-.15.3-.15.6 0 .9C3.2 16.71 7.305 19.5 12 19.5s8.8-2.79 10.95-6.9c.15-.3.15-.6 0-.9C20.8 7.29 16.695 4.5 12 4.5zm0 12c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.654 0-3 1.346-3 3s1.346 3 3 3 3-1.346 3-3-1.346-3-3-3z"/></g>
    </svg>`;
  }

  // Extract text from the closest article/tweet
  function extractPostText(menuElement) {
    try {
      // Strategy 1: Look for the focused/detailed tweet (when viewing a single tweet)
      const detailedTweet = document.querySelector('article[data-testid="tweet"][tabindex="-1"]');
      if (detailedTweet) {
        const tweetText = detailedTweet.querySelector('[data-testid="tweetText"]');
        if (tweetText && tweetText.textContent.trim().length > 0) {
          console.log('RSVP: Extracted from detailed tweet view');
          return tweetText.textContent.trim();
        }
      }

      // Strategy 2: Walk up from menu to find article
      let current = menuElement;
      let article = null;

      for (let i = 0; i < 30; i++) {
        if (!current || !current.parentElement) break;
        current = current.parentElement;

        if (current.tagName === 'ARTICLE') {
          article = current;
          break;
        }
      }

      if (article) {
        const tweetText = article.querySelector('[data-testid="tweetText"]');
        if (tweetText && tweetText.textContent.trim().length > 0) {
          console.log('RSVP: Extracted from article via menu traversal');
          return tweetText.textContent.trim();
        }
      }

      // Strategy 3: Find all articles and use the first one with substantial text
      const allArticles = document.querySelectorAll('article');
      console.log(`RSVP: Found ${allArticles.length} articles on page`);

      for (const art of allArticles) {
        const tweetText = art.querySelector('[data-testid="tweetText"]');
        if (tweetText && tweetText.textContent.trim().length > 50) {
          console.log('RSVP: Extracted from first substantial article');
          return tweetText.textContent.trim();
        }
      }

      // Strategy 4: Try any element with lang attribute (less reliable)
      const langElements = document.querySelectorAll('[lang][dir="auto"]');
      for (const el of langElements) {
        const text = el.textContent.trim();
        if (text.length > 50 && !text.includes('Post') && !text.includes('Repost')) {
          console.log('RSVP: Extracted from lang element');
          return text;
        }
      }

      console.log('RSVP: Could not find tweet text with any strategy');
      return null;
    } catch (error) {
      console.error('RSVP: Error extracting post text:', error);
      return null;
    }
  }

  // Extract text from an article page
  function extractArticleText() {
    try {
      // Check if we're on an article URL
      if (!window.location.pathname.includes('/article/')) {
        return null;
      }

      // Try to find article content
      const selectors = [
        'article[role="article"]',
        '[data-testid="article-content"]',
        'main article'
      ];

      for (const selector of selectors) {
        const articleContent = document.querySelector(selector);
        if (articleContent) {
          const paragraphs = articleContent.querySelectorAll('p, h1, h2, h3, h4, h5, h6');
          if (paragraphs.length > 0) {
            const text = Array.from(paragraphs)
              .map(el => el.textContent)
              .filter(t => t && t.trim().length > 0)
              .join('\n\n')
              .trim();

            if (text.length > 100) {
              return text;
            }
          }
        }
      }

      return null;
    } catch (error) {
      console.error('RSVP: Error extracting article text:', error);
      return null;
    }
  }

  // Get text content based on context
  function getTextContent(menuElement) {
    // Try article first
    const articleText = extractArticleText();
    if (articleText && articleText.length > 100) {
      return articleText;
    }

    // Otherwise extract from post
    return extractPostText(menuElement);
  }

  // Create our "Speed read" menu item by cloning the first menu item
  function createSpeedReadMenuItem(menu) {
    // Find the first menu item to clone
    const firstMenuItem = menu.querySelector('[role="menuitem"]');
    if (!firstMenuItem) {
      console.error('RSVP: No menu item found to clone');
      return null;
    }

    // Clone it
    const menuItem = firstMenuItem.cloneNode(true);
    menuItem.setAttribute('data-rsvp-speed-read', 'true');

    // Replace the icon
    const iconContainer = menuItem.querySelector('.css-175oi2r.r-1777fci');
    if (iconContainer) {
      iconContainer.innerHTML = getSpeedReadIcon();
    }

    // Replace the text
    const textSpan = menuItem.querySelector('.css-1jxf684');
    if (textSpan) {
      textSpan.textContent = 'Speed read';
    }

    return menuItem;
  }

  // Inject our "Speed read" menu item
  function injectSpeedReadOption(menu) {
    // Check if already processed
    if (processedMenus.has(menu)) {
      return;
    }
    processedMenus.add(menu);

    // Check if already injected
    if (menu.querySelector('[data-rsvp-speed-read]')) {
      return;
    }

    // Create and insert menu item
    const speedReadItem = createSpeedReadMenuItem();

    // Add click handler
    speedReadItem.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      const text = getTextContent(menu);

      if (!text || text.length === 0) {
        alert('Could not extract text from this post/article');
        return;
      }

      // Close the menu by clicking outside
      setTimeout(() => {
        document.body.click();
      }, 50);

      // Trigger the custom event to start reading
      setTimeout(() => {
        const event = new CustomEvent('rsvpStartReading', {
          detail: { text: text }
        });
        document.dispatchEvent(event);
      }, 150);
    });

    // Add hover effect
    speedReadItem.addEventListener('mouseenter', () => {
      speedReadItem.style.backgroundColor = isDarkTheme() ? 'rgba(255, 255, 255, 0.03)' : 'rgba(0, 0, 0, 0.03)';
    });

    speedReadItem.addEventListener('mouseleave', () => {
      speedReadItem.style.backgroundColor = 'transparent';
    });

    // Insert at the top of the menu
    try {
      const firstItem = menu.querySelector('[role="menuitem"]');

      if (firstItem) {
        // Try to insert before the first menu item
        if (firstItem.parentNode) {
          firstItem.parentNode.insertBefore(speedReadItem, firstItem);
          console.log('RSVP: Successfully injected Speed read option before first item');
        } else {
          // Parent not accessible, try prepending to menu
          menu.insertBefore(speedReadItem, menu.firstChild);
          console.log('RSVP: Injected at menu start');
        }
      } else if (menu.firstChild) {
        menu.insertBefore(speedReadItem, menu.firstChild);
        console.log('RSVP: Injected before first child');
      } else {
        menu.appendChild(speedReadItem);
        console.log('RSVP: Injected via append');
      }
    } catch (error) {
      console.error('RSVP: Failed to insert menu item:', error);
      // Try one more time with appendChild as fallback
      try {
        menu.appendChild(speedReadItem);
        console.log('RSVP: Injected via appendChild fallback');
      } catch (e) {
        console.error('RSVP: Failed appendChild fallback:', e);
      }
    }
  }

  // Observe for menu openings
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType !== Node.ELEMENT_NODE) return;

        // Look for role="menu" in the added node or its children
        const menus = [];

        if (node.getAttribute && node.getAttribute('role') === 'menu') {
          console.log('RSVP: Found menu element directly');
          menus.push(node);
        }

        if (node.querySelectorAll) {
          const foundMenus = node.querySelectorAll('[role="menu"]');
          if (foundMenus.length > 0) {
            console.log(`RSVP: Found ${foundMenus.length} menu(s) in children`);
          }
          menus.push(...Array.from(foundMenus));
        }

        // Also look for X's menu structure (div with specific pattern)
        if (node.querySelectorAll) {
          // Look for divs that contain menuitems (X's menu structure)
          const potentialMenus = node.querySelectorAll('div[class*="r-kemksi"]');
          potentialMenus.forEach(elem => {
            // Check if it contains menu items
            const hasMenuItems = elem.querySelector('[role="menuitem"]');
            if (hasMenuItems && !elem.getAttribute('role')) {
              console.log('RSVP: Found X-style menu container');
              menus.push(elem);
            }
          });
        }

        // Process each menu found
        menus.forEach(menu => {
          console.log('RSVP: Processing menu:', menu);
          // Small delay to ensure menu is fully rendered
          setTimeout(() => {
            injectSpeedReadOption(menu);
          }, 50);
        });
      });
    });
  });

  // Wait for document to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startObserving);
  } else {
    startObserving();
  }

  function startObserving() {
    // Start observing
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    console.log('RSVP Speed Reader: X integration loaded and observing');

    // Also process any menus that already exist
    const existingMenus = document.querySelectorAll('[role="menu"]');
    if (existingMenus.length > 0) {
      console.log(`RSVP: Found ${existingMenus.length} existing menus`);
      existingMenus.forEach(menu => {
        setTimeout(() => {
          injectSpeedReadOption(menu);
        }, 100);
      });
    }
  }
})();
