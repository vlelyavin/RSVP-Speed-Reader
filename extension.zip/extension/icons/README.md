# Extension Icons

To complete the extension setup, you need to add three icon files:

- `icon16.png` (16x16 pixels)
- `icon48.png` (48x48 pixels)
- `icon128.png` (128x128 pixels)

## Quick Icon Creation Options:

### Option 1: Use an Online Tool
1. Go to https://www.favicon-generator.org/ or https://realfavicongenerator.net/
2. Upload the `icon.svg` file in this directory
3. Generate icons in the required sizes
4. Save them in this directory

### Option 2: Use Command Line (if you have ImageMagick)
```bash
convert icon.svg -resize 16x16 icon16.png
convert icon.svg -resize 48x48 icon48.png
convert icon.svg -resize 128x128 icon128.png
```

### Option 3: Use a Graphics Editor
1. Open `icon.svg` in Figma, Sketch, or Photoshop
2. Export as PNG in the three required sizes
3. Save in this directory

## Temporary Workaround
For testing, you can temporarily use any PNG images renamed to these filenames. The extension will load without proper icons, but Chrome may show a default icon.

The SVG template (`icon.svg`) shows a simple red "R" on black background that matches the extension's branding.
