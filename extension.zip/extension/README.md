# RSVP Speed Reader - Chrome Extension

A minimal Chrome extension that lets you read selected text from any webpage using the RSVP (Rapid Serial Visual Presentation) technique.

## Features

- **Context Menu Integration**: Right-click selected text → "Read with RSVP"
- **Fullscreen Overlay**: Distraction-free reading with ORP highlighting
- **Keyboard Controls**: Space, arrows, Esc, R for full control
- **Adjustable Settings**: Speed (100-1000 WPM) and font size (40-120px)
- **No Persistence**: Lightweight, no data collection or storage

## Quick Start

1. **Load the extension**:
   - Open `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the `extension/` directory

2. **Use it**:
   - Select text on any webpage
   - Right-click → "Read with RSVP"
   - Use keyboard shortcuts to control playback

See [INSTALLATION.md](INSTALLATION.md) for detailed instructions.

## Architecture

```
extension/
├── manifest.json          # Manifest v3 configuration
├── background.js          # Context menu handler (~20 lines)
├── content-script.js      # Overlay injection & RSVP logic (~350 lines)
├── rsvp-core.js          # Pure RSVP functions (from web app)
└── styles/
    ├── overlay.css       # Fullscreen overlay styles
    └── reset.css         # Style isolation
```

## Technical Details

- **Manifest Version**: 3
- **Permissions**: `contextMenus`, `activeTab` (minimal)
- **Shadow DOM**: Used for style isolation from host page
- **ES6 Modules**: Modern JavaScript with imports
- **No Dependencies**: Pure vanilla JS, no frameworks
- **No Storage**: All state is in-memory only

## Code Reusability

This extension reuses ~70% of code from the RSVP Speed Reader web app:
- **RSVP algorithm**: `calculateORP()`, `parseText()`, `calculateDelay()` - unchanged
- **Playback logic**: `showNextWord()`, `togglePause()` - adapted for Shadow DOM
- **Styles**: Extracted from web app and adapted for overlay

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Space | Pause/Resume |
| Escape | Close overlay |
| ← → | Navigate words manually |
| R | Reset to beginning |
| ↑ ↓ | Adjust speed ±50 WPM |

## Limitations

- No settings persistence (by design)
- No history tracking
- No PDF support
- Text selection only
- Works on web pages only (not Chrome system pages)

## What's Different from the Web App?

**Removed features** (for simplicity):
- ❌ localStorage persistence
- ❌ Document history
- ❌ PDF upload
- ❌ Draft auto-save
- ❌ Right sidebar settings panel
- ❌ Welcome popup

**New features**:
- ✅ Context menu integration
- ✅ Works on any webpage
- ✅ Shadow DOM isolation
- ✅ Inline settings (left sidebar)

## Development

To modify the extension:

1. Edit files in `extension/`
2. Go to `chrome://extensions/`
3. Click refresh icon on the extension
4. Test on any webpage

Debug with:
- **Background script**: Right-click extension → Inspect service worker
- **Content script**: F12 console on page with overlay active

## Publishing to Chrome Web Store

1. Add proper icons (see `icons/README.md`)
2. Test thoroughly on multiple sites
3. Create privacy policy (even with no data collection)
4. Prepare promotional images
5. Pay $5 developer fee
6. Submit to Chrome Web Store

## Related

- **Web App**: [RSVP Speed Reader](https://vlelyavin.github.io/RSVP-Speed-Reader/)
- **Source Code**: `/src/` directory in this repository

---

Built with ❤️ using vanilla JavaScript and the power of RSVP reading technique.
