/* RSVP Speed Reader - Content Script */
/* Exact replica of web app reading interface */

// ===== RSVP CORE FUNCTIONS =====

function calculateORP(word) {
  const length = word.length;
  if (length <= 3) return 0;
  if (length <= 5) return 1;
  if (length <= 9) return 2;
  return 3;
}

function parseText(text) {
  return text
    .trim()
    .split(/\s+/)
    .filter((word) => word.length > 0);
}

function hasPunctuation(word) {
  return /[.,!?;:]$/.test(word);
}

function calculateDelay(word, settings) {
  const baseDelay = (60 / settings.speed) * 1000;
  const punctuationDelay = hasPunctuation(word) ? settings.punctuationPause : 0;
  return baseDelay + punctuationDelay;
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

let measureElement = null;
function getTextWidth(text, fontSize, fontFamily) {
  if (!measureElement) {
    measureElement = document.createElement("span");
    measureElement.style.position = "absolute";
    measureElement.style.visibility = "hidden";
    measureElement.style.whiteSpace = "nowrap";
    document.body.appendChild(measureElement);
  }
  measureElement.style.fontSize = fontSize + "px";
  measureElement.style.fontFamily = fontFamily;
  measureElement.textContent = text;
  return measureElement.offsetWidth;
}

// ===== STATE =====

let state = {
  words: [],
  currentIndex: 0,
  isPlaying: false,
  timeoutId: null,
  settings: {
    fontSize: 70,
    speed: 300,
    punctuationPause: 150,
    fontFamily: "ui-serif, Georgia, 'Times New Roman', Times, serif",
  },
};

// ===== MESSAGE LISTENERS =====

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "startReading") {
    removeOverlay();
    injectOverlay(message.text);
  }
});

// Listen for custom events from X integration
document.addEventListener("rsvpStartReading", (event) => {
  if (event.detail && event.detail.text) {
    removeOverlay();
    injectOverlay(event.detail.text);
  }
});

// ===== OVERLAY INJECTION =====

function injectOverlay(text) {
  state.words = parseText(text);
  state.currentIndex = 0;

  if (state.words.length === 0) {
    alert("No text to read");
    return;
  }

  const overlayContainer = document.createElement("div");
  overlayContainer.id = "rsvp-overlay-container";

  const shadowRoot = overlayContainer.attachShadow({ mode: "open" });
  shadowRoot.innerHTML = getOverlayHTML();

  const styleLink = document.createElement("link");
  styleLink.rel = "stylesheet";
  styleLink.href = chrome.runtime.getURL("styles/overlay.css");
  shadowRoot.appendChild(styleLink);

  document.body.appendChild(overlayContainer);

  // Make overlay focusable and auto-focus it for keyboard events
  overlayContainer.setAttribute("tabindex", "-1");
  overlayContainer.focus();

  setupControls(shadowRoot);
  setupKeyboardShortcuts();
  setupWindowResize(shadowRoot);

  startReading(shadowRoot);
}

function getOverlayHTML() {
  return `
    <div class="overlay-backdrop">
      <!-- Sidebar Toggle Button -->
      <button class="sidebar-toggle-btn sidebar-toggle-left" id="openSettingsBtn">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M3 8L15 8M15 8C15 9.65686 16.3431 11 18 11C19.6569 11 21 9.65685 21 8C21 6.34315 19.6569 5 18 5C16.3431 5 15 6.34315 15 8ZM9 16L21 16M9 16C9 17.6569 7.65685 19 6 19C4.34315 19 3 17.6569 3 16C3 14.3431 4.34315 13 6 13C7.65685 13 9 14.3431 9 16Z"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          ></path>
        </svg>
        <span class="tooltip">Open reader settings</span>
      </button>

      <!-- Sidebar Overlay -->
      <div class="sidebar-overlay" id="sidebarOverlay"></div>

      <!-- Left Sidebar - Settings -->
      <div class="sidebar-left" id="sidebarLeft">
        <div class="sidebar-left-content">
          <div class="sidebar-header">
            <p class="sidebar-title">Reader settings</p>
            <button class="sidebar-close-btn" id="closeSettingsBtn">Close</button>
          </div>
          <div class="sidebar-settings">
            <div class="sidebar-setting">
              <label class="sidebar-setting-label">Font size</label>
              <div class="sidebar-setting-slider-wrapper">
                <input type="range" class="slider" id="fontSizeSlider" min="24" max="120" value="70" />
                <span class="slider-value" id="fontSizeValue">70px</span>
              </div>
            </div>
            <div class="sidebar-setting">
              <label class="sidebar-setting-label">Reading speed</label>
              <div class="sidebar-setting-slider-wrapper">
                <input type="range" class="slider" id="speedSlider" min="100" max="1000" value="300" step="50" />
                <span class="slider-value" id="speedValue">300wpm</span>
              </div>
            </div>
            <div class="sidebar-setting">
              <label class="sidebar-setting-label">Punctuation pause</label>
              <div class="sidebar-setting-slider-wrapper">
                <input type="range" class="slider" id="punctuationPauseSlider" min="0" max="500" value="150" step="50" />
                <span class="slider-value" id="punctuationPauseValue">150ms</span>
              </div>
            </div>
          </div>
          <div class="hint">
            <div class="hint-item"><span>Esc</span> close</div>
            <div class="hint-item"><span>Space</span> start/pause</div>
            <div class="hint-item"><span>R</span> reset</div>
            <div class="hint-item"><span>← →</span> step words</div>
          </div>
        </div>
      </div>

      <!-- Reading Interface -->
      <div class="reading-interface" id="readingInterface">
        <div class="guide-lines">
          <div class="guide-line-top"></div>
          <div class="guide-line-bottom"></div>
          <div class="guide-line-vertical-top"></div>
          <div class="guide-line-vertical-bottom"></div>
        </div>
        <div class="word-display-container">
          <div class="word-display" id="wordDisplay"></div>
        </div>
        <div class="controls">
          <div class="progress-bar-container">
            <div class="progress-percentage" id="progressPercentage">0.00%</div>
            <div class="progress-bar-wrapper" id="progressBarWrapper">
              <div class="progress-bar-fill" id="progressBarFill"></div>
            </div>
            <div class="progress-controls-hint">
              <div class="hint-item"><span>Esc</span> escape</div>
              <div class="hint-item"><span>Space</span> start/pause</div>
              <div class="hint-item"><span>R</span> reset</div>
              <div class="hint-item"><span>← →</span> step words</div>
            </div>
          </div>
          <div class="controls-row">
            <button class="control-button" id="pauseButton">Pause</button>
            <button class="control-button" id="resetButton">Reset</button>
            <button class="control-button" id="stopButton">Close</button>
          </div>
        </div>
      </div>

      <!-- Close Button -->
      <button class="close-button" id="closeButton">×</button>
    </div>
  `;
}

// ===== CONTROLS SETUP =====

function setupControls(shadowRoot) {
  const pauseBtn = shadowRoot.getElementById("pauseButton");
  const resetButton = shadowRoot.getElementById("resetButton");
  const stopBtn = shadowRoot.getElementById("stopButton");
  const closeBtn = shadowRoot.getElementById("closeButton");
  const openSettingsBtn = shadowRoot.getElementById("openSettingsBtn");
  const closeSettingsBtn = shadowRoot.getElementById("closeSettingsBtn");
  const sidebarLeft = shadowRoot.getElementById("sidebarLeft");
  const sidebarOverlay = shadowRoot.getElementById("sidebarOverlay");

  const wordDisplay = shadowRoot.getElementById("wordDisplay");
  const guideLines = shadowRoot.querySelector(".guide-lines");
  const progressPercentage = shadowRoot.getElementById("progressPercentage");
  const progressBarWrapper = shadowRoot.getElementById("progressBarWrapper");
  const progressBarFill = shadowRoot.getElementById("progressBarFill");

  pauseBtn.addEventListener("click", () => togglePause(shadowRoot));
  stopBtn.addEventListener("click", stopReading);
  closeBtn.addEventListener("click", stopReading);
  resetButton.addEventListener("click", () => resetProgress(shadowRoot));

  // Open sidebar button
  openSettingsBtn.addEventListener("click", () => {
    sidebarLeft.classList.add("open");
    sidebarOverlay.classList.add("active");
  });

  // Close sidebar button
  closeSettingsBtn.addEventListener("click", () => {
    sidebarLeft.classList.remove("open");
    sidebarOverlay.classList.remove("active");
  });

  // Sidebar overlay click to close
  sidebarOverlay.addEventListener("click", () => {
    sidebarLeft.classList.remove("open");
    sidebarOverlay.classList.remove("active");
  });

  // Font size slider
  const fontSizeSlider = shadowRoot.getElementById("fontSizeSlider");
  const fontSizeValue = shadowRoot.getElementById("fontSizeValue");

  fontSizeSlider.addEventListener("input", (e) => {
    state.settings.fontSize = parseInt(e.target.value);
    fontSizeValue.textContent = `${state.settings.fontSize}px`;
    if (state.currentIndex > 0 && state.currentIndex <= state.words.length) {
      displayWord(state.words[state.currentIndex - 1], shadowRoot);
    }
  });

  // Speed slider
  const speedSlider = shadowRoot.getElementById("speedSlider");
  const speedValue = shadowRoot.getElementById("speedValue");

  speedSlider.addEventListener("input", (e) => {
    state.settings.speed = parseInt(e.target.value);
    speedValue.textContent = `${state.settings.speed}wpm`;
  });

  // Punctuation pause slider
  const punctuationPauseSlider = shadowRoot.getElementById("punctuationPauseSlider");
  const punctuationPauseValue = shadowRoot.getElementById("punctuationPauseValue");

  punctuationPauseSlider.addEventListener("input", (e) => {
    state.settings.punctuationPause = parseInt(e.target.value);
    punctuationPauseValue.textContent = `${state.settings.punctuationPause}ms`;
  });

  // Progress bar interaction
  let isDraggingProgress = false;

  function updateProgressFromPosition(
    clientX,
    progressBarWrapper,
    progressBarFill,
    progressPercentage,
    wordDisplay,
    guideLines
  ) {
    const rect = progressBarWrapper.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    const percent = x / rect.width;
    const newIndex = Math.floor(percent * state.words.length);

    state.currentIndex = Math.max(0, Math.min(newIndex, state.words.length - 1));

    if (state.words.length > 0) {
      displayWord(state.words[state.currentIndex], wordDisplay, guideLines);
      updateProgress(progressBarFill, progressPercentage);
    }
  }

  function updateProgress(progressBarFill, progressPercentage) {
    // Update progress bar
    const progressPercent = state.words.length > 0 ? (state.currentIndex / state.words.length) * 100 : 0;
    progressPercentage.textContent = `${progressPercent.toFixed(2)}%`;
    progressBarFill.style.width = `${progressPercent}%`;
  }

  function setupProgressBar(progressBarWrapper, progressBarFill, progressPercentage, wordDisplay, guideLines) {
    progressBarWrapper.addEventListener("mousedown", (e) => {
      isDraggingProgress = true;
      updateProgressFromPosition(
        e.clientX,
        progressBarWrapper,
        progressBarFill,
        progressPercentage,
        wordDisplay,
        guideLines
      );
    });

    document.addEventListener("mousemove", (e) => {
      if (isDraggingProgress) {
        updateProgressFromPosition(
          e.clientX,
          progressBarWrapper,
          progressBarFill,
          progressPercentage,
          wordDisplay,
          guideLines
        );
      }
    });

    document.addEventListener("mouseup", () => {
      isDraggingProgress = false;
    });

    progressBarWrapper.addEventListener("click", (e) => {
      if (!isDraggingProgress) {
        updateProgressFromPosition(
          e.clientX,
          progressBarWrapper,
          progressBarFill,
          progressPercentage,
          wordDisplay,
          guideLines
        );
      }
    });
  }
  setupProgressBar(progressBarWrapper, progressBarFill, progressPercentage, wordDisplay, guideLines);
}

// ===== KEYBOARD SHORTCUTS =====

let keydownHandler = null;

function setupKeyboardShortcuts() {
  keydownHandler = (e) => handleKeydown(e);
  document.addEventListener("keydown", keydownHandler);
}

function handleKeydown(e) {
  const overlayContainer = document.getElementById("rsvp-overlay-container");
  if (!overlayContainer) return;

  const shadowRoot = overlayContainer.shadowRoot;

  switch (e.key) {
    case " ":
      e.preventDefault();
      togglePause(shadowRoot);
      break;
    case "Escape":
      e.preventDefault();
      removeOverlay();
      break;
    case "ArrowLeft":
      e.preventDefault();
      stepPrevWord(shadowRoot);
      break;
    case "ArrowRight":
      e.preventDefault();
      stepNextWord(shadowRoot);
      break;
    case "r":
    case "R":
      e.preventDefault();
      resetProgress(shadowRoot);
      break;
    case "ArrowUp":
      e.preventDefault();
      adjustSpeed(50, shadowRoot);
      break;
    case "ArrowDown":
      e.preventDefault();
      adjustSpeed(-50, shadowRoot);
      break;
  }
}

// ===== RSVP PLAYBACK =====

function startReading(shadowRoot) {
  state.isPlaying = true;
  showNextWord(shadowRoot);
}

function showNextWord(shadowRoot) {
  if (state.currentIndex >= state.words.length) {
    setTimeout(() => {
      alert("Playback has been finished");
      removeOverlay();
    }, 500);
    return;
  }

  const word = state.words[state.currentIndex];
  displayWord(word, shadowRoot);
  updateProgress(shadowRoot);

  const delay = calculateDelay(word, state.settings);
  state.currentIndex++;

  if (state.isPlaying && state.currentIndex < state.words.length) {
    state.timeoutId = setTimeout(() => showNextWord(shadowRoot), delay);
  } else if (state.currentIndex >= state.words.length) {
    state.timeoutId = setTimeout(() => {
      alert("Playback has been finished");
      removeOverlay();
    }, delay);
  }
}

function displayWord(word, shadowRoot) {
  const orpIndex = calculateORP(word);
  const beforeORP = word.substring(0, orpIndex);
  const orpLetter = word.substring(orpIndex, orpIndex + 1);
  const afterORP = word.substring(orpIndex + 1);

  const wordDisplay = shadowRoot.getElementById("wordDisplay");
  wordDisplay.style.fontSize = state.settings.fontSize + "px";
  wordDisplay.style.fontFamily = state.settings.fontFamily;

  wordDisplay.innerHTML = `
    <span class="word-part">${escapeHtml(beforeORP)}</span>
    <span class="word-part orp-letter">${escapeHtml(orpLetter)}</span>
    <span class="word-part">${escapeHtml(afterORP)}</span>
  `;

  const fontFamily = state.settings.fontFamily;
  const beforeWidth = getTextWidth(beforeORP, state.settings.fontSize, fontFamily);
  const orpWidth = getTextWidth(orpLetter, state.settings.fontSize, fontFamily);
  const totalWidth = getTextWidth(word, state.settings.fontSize, fontFamily);

  const offset = beforeWidth + orpWidth / 2 - totalWidth / 2;
  wordDisplay.style.transform = `translateX(${-offset}px)`;
}

function updateProgress(shadowRoot) {
  const progressFill = shadowRoot.getElementById("progressBarFill");
  const progressText = shadowRoot.getElementById("progressPercentage");

  const percentage = state.words.length > 0 ? ((state.currentIndex / state.words.length) * 100).toFixed(2) : 0;

  progressFill.style.width = percentage + "%";
  progressText.textContent = percentage + "%";
}

function togglePause(shadowRoot) {
  state.isPlaying = !state.isPlaying;
  const pauseBtn = shadowRoot.getElementById("pauseButton");
  pauseBtn.textContent = state.isPlaying ? "Pause" : "Resume";

  if (state.isPlaying) {
    showNextWord(shadowRoot);
  } else {
    clearTimeout(state.timeoutId);
  }
}

function stopReading() {
  removeOverlay();
}

function removeOverlay() {
  state.isPlaying = false;
  clearTimeout(state.timeoutId);

  const overlay = document.getElementById("rsvp-overlay-container");
  if (overlay) {
    overlay.remove();
  }

  if (keydownHandler) {
    document.removeEventListener("keydown", keydownHandler);
    keydownHandler = null;
  }

  state.words = [];
  state.currentIndex = 0;
}

function stepPrevWord(shadowRoot) {
  if (state.words.length === 0) return;

  if (state.isPlaying) {
    state.isPlaying = false;
    clearTimeout(state.timeoutId);
    shadowRoot.getElementById("pauseButton").textContent = "Resume";
  }

  if (state.currentIndex > 0) {
    state.currentIndex--;
    displayWord(state.words[state.currentIndex], shadowRoot);
    updateProgress(shadowRoot);
  }
}

function stepNextWord(shadowRoot) {
  if (state.words.length === 0) return;

  if (state.isPlaying) {
    state.isPlaying = false;
    clearTimeout(state.timeoutId);
    shadowRoot.getElementById("pauseButton").textContent = "Resume";
  }

  if (state.currentIndex < state.words.length - 1) {
    state.currentIndex++;
    displayWord(state.words[state.currentIndex], shadowRoot);
    updateProgress(shadowRoot);
  }
}

function resetProgress(shadowRoot) {
  if (state.words.length === 0) return;

  if (state.isPlaying) {
    state.isPlaying = false;
    clearTimeout(state.timeoutId);
    shadowRoot.getElementById("pauseButton").textContent = "Resume";
  }

  state.currentIndex = 0;
  displayWord(state.words[state.currentIndex], shadowRoot);
  updateProgress(shadowRoot);
}

function adjustSpeed(delta, shadowRoot) {
  const newSpeed = Math.max(100, Math.min(1000, state.settings.speed + delta));
  state.settings.speed = newSpeed;

  const speedSlider = shadowRoot.getElementById("speedSlider");
  const speedValue = shadowRoot.getElementById("speedValue");

  speedSlider.value = newSpeed;
  speedValue.textContent = `${newSpeed}wpm`;
}

// ===== RESPONSIVE HELPERS =====

function isMobile() {
  return window.innerWidth <= 768;
}

function updateFontSizeSliderRange(fontSizeSlider) {
  const isMobileDevice = isMobile();
  if (isMobileDevice) {
    // Mobile: divide by 2.5 (24/2.5=9.6≈10, 120/2.5=48, 72/2.5=28.8≈29)
    fontSizeSlider.min = 10;
    fontSizeSlider.max = 48;
    // If current value is desktop range, convert to mobile range
    if (state.settings.fontSize > 48) {
      state.settings.fontSize = Math.round(state.settings.fontSize / 2.5);
    }
    // Set default if no saved value or value is out of range
    if (!state.settings.fontSize || state.settings.fontSize < 10 || state.settings.fontSize > 48) {
      state.settings.fontSize = 29; // Default mobile: 72/2.5 ≈ 29
    }
  } else {
    // Desktop: original range
    fontSizeSlider.min = 24;
    fontSizeSlider.max = 120;
    // If current value is mobile range, convert to desktop range
    if (state.settings.fontSize <= 48) {
      state.settings.fontSize = Math.round(state.settings.fontSize * 2.5);
    }
    // Set default if no saved value or value is out of range
    if (!state.settings.fontSize || state.settings.fontSize < 24 || state.settings.fontSize > 120) {
      state.settings.fontSize = 72; // Default desktop
    }
  }
}

function setupWindowResize(shadowRoot) {
  const fontSizeSlider = shadowRoot.getElementById("fontSizeSlider");
  const fontSizeValue = shadowRoot.getElementById("fontSizeValue");

  // Initialize font size slider range
  updateFontSizeSliderRange(fontSizeSlider);
  fontSizeSlider.value = state.settings.fontSize;
  fontSizeValue.textContent = `${state.settings.fontSize}px`;

  // Window resize handler with debouncing
  let resizeTimeout;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      const oldValue = state.settings.fontSize;
      updateFontSizeSliderRange(fontSizeSlider);

      // Update display if value changed
      if (oldValue !== state.settings.fontSize) {
        fontSizeSlider.value = state.settings.fontSize;
        fontSizeValue.textContent = `${state.settings.fontSize}px`;

        // Update word display if reading is active
        if (state.words.length > 0 && state.currentIndex > 0) {
          displayWord(state.words[state.currentIndex - 1], shadowRoot);
        }
      }
    }, 100);
  });
}
