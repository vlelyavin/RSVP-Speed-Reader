// Register context menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "rsvp-reader",
    title: "Read with RSVP",
    contexts: ["selection"]
  });
});

// Handle menu click
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "rsvp-reader" && info.selectionText) {
    // Send selected text to content script
    chrome.tabs.sendMessage(tab.id, {
      action: "startReading",
      text: info.selectionText
    });
  }
});
